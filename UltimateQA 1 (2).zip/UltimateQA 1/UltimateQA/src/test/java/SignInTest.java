import signIn.UltimateQASignUP;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.FileReader;

public class SignInTest {
    public static WebDriver driver;

    public UltimateQASignUP signIn;
    private static JSONObject userData;

   /* static {
        JSONParser parser = new JSONParser();
        try {
            Object obj;
                 obj   = parser.parse(new FileReader("src/main/resources/UltimateQA.json"));
            userData = (JSONObject) obj;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
    @BeforeMethod
    public void setup() {
        // Specify the path to your downloaded ChromeDriver executable
        //System.setProperty("webdriver.chrome.driver", "C:\\WebDriver\\chromedriver.exe");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        signIn = new UltimateQASignUP (driver);
        WebDriverManager.chromedriver().setup();
        driver.manage().window().maximize();
        driver.get("https://ultimateqa.com/automation");
    }
    @Test(priority = 1)
    public void loginTest() {
        try {
            FileReader fileReader = new FileReader("src/main/resources/UltimateQA.json");
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonData ;
            jsonData = (JSONObject) jsonParser.parse(fileReader);
            assert jsonData != null;
            signIn.LoginAutomation(driver);
            signIn.EnterEmail(jsonData.get("email").toString());
            signIn.EnterPassword(jsonData.get("password").toString());
            signIn.SignIn_Button(driver);
            signIn.Account(driver);
            signIn.MyAccount(driver);
            signIn.ProfilePhoto(jsonData.get("pathProfile").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
           // driver.quit();


        }
    }}