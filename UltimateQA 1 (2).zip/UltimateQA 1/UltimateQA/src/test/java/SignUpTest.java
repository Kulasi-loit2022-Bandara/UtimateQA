//import org.UltimateQASignUP;
import signUp.UltimateQASignUP;
import org.json.simple.JSONObject;
//import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SignUpTest {

    public static WebDriver driver;

    private UltimateQASignUP signUP;
    private static JSONObject userData;

    static {
        JSONParser parser = new JSONParser();
       try {
            Object obj = parser.parse(new FileReader("src/main/resources/UltimateQA.json"));
            userData = (JSONObject) obj;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @BeforeMethod
    public void setup() {
        // Specify the path to your downloaded ChromeDriver executable
        //System.setProperty("webdriver.chrome.driver", "C:\\WebDriver\\chromedriver.exe");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        signUP = new UltimateQASignUP(driver);
        WebDriverManager.chromedriver().setup();
        driver.manage().window().maximize();
        driver.get("https://ultimateqa.com/automation");
    }

    @Test(priority = 1)
    public void loginTest() {
        try {
            FileReader fileReader = new FileReader("src/main/resources/UltimateQA.json");
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonData = (JSONObject) jsonParser.parse(fileReader);
            //org.json.simple.JSONObject jsonData = (org.json.simple.JSONObject) jsonParser.parse(fileReader);
            assert jsonData != null;

            signUP.LoginAutomation(driver);
            signUP.CreateANewAccount(driver);


            signUP.EnterFirstName(jsonData.get("firstName").toString());
            signUP.EnterLastName(jsonData.get("lastName").toString());
            signUP.EnterEmail(jsonData.get("email").toString());
            signUP.EnterPassword(jsonData.get("password").toString());
            signUP.Agreement();
            signUP.SignUP_BUTTON();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @AfterMethod
    public void tearDown() {if (driver != null) {
        //driver.quit();
    }}}